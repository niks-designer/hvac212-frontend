interface HeroSectionTitleDescription {
    title?: string;
    short_description?: string;
}

interface CTAButton {
    title?: string;
    url?: string;
    target?: string;
}

interface HeroCTAButtons {
    primary_button?: CTAButton | null;
    secondary_button?: CTAButton | null;
}

interface HeadingWithBottomActionProps {
    title?: HeroSectionTitleDescription | null;
    bottomAction?: string | null;
    ctaButtons?: HeroCTAButtons | null;
    className?: string;
}

export default function HeadingWithBottomAction({
    title,
    bottomAction,
    ctaButtons,
    className,
}: HeadingWithBottomActionProps) {
    const heading = title?.title?.trim() || "";
    const shortDescription = title?.short_description || "";
    const primaryButton = ctaButtons?.primary_button;
    const secondaryButton = ctaButtons?.secondary_button;

    return (
        <section className={`relative overflow-hidden ${className || "py-16"}`}>
            <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 opacity-95"></div>
            <div className="container">
                <div className="relative z-10 flex max-w-5xl flex-col gap-4 text-center mx-auto">
                    {heading && (
                        <h2 className="h2-title">
                            {heading}
                        </h2>
                    )}

                    {shortDescription && (
                        <div
                            className="prose"
                            dangerouslySetInnerHTML={{ __html: shortDescription }}
                        />
                    )}

                    {bottomAction && (
                        <div
                            className="action-link font-bold text-2xl"
                            dangerouslySetInnerHTML={{ __html: bottomAction }}
                        />
                    )}

                    {(primaryButton?.url || secondaryButton?.url) && (
                        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                            {primaryButton?.url && (
                                <a
                                    href={primaryButton.url}
                                    target={primaryButton.target === "_blank" ? "_blank" : "_self"}
                                    rel={
                                        primaryButton.target === "_blank"
                                            ? "noopener noreferrer"
                                            : undefined
                                    }
                                    className="theme-btn bgc-yellow"
                                >
                                    {primaryButton.title || "Learn More"}
                                </a>
                            )}
                            {secondaryButton?.url && (
                                <a
                                    href={secondaryButton.url}
                                    target={secondaryButton.target === "_blank" ? "_blank" : "_self"}
                                    rel={
                                        secondaryButton.target === "_blank"
                                            ? "noopener noreferrer"
                                            : undefined
                                    }
                                    className="theme-btn theme-btn-outline"
                                >
                                    {secondaryButton.title || "Get Started"}
                                </a>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
}
